const e=e=>{const s=[...e.pc?["webrtc"]:[],...!e.pc&&e.mseCodecs?["mse","hls"]:[]];return s.length?s:void 0};export{e as g};
